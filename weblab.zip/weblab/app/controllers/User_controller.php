<?php
defined('PREVENT_DIRECT_ACCESS') OR exit('No direct script access allowed');

class User_controller extends Controller {
    public function home(){
        $this->call->model('User_model');
        $data['user'] = $this->User_model->getUsers();
        $this->call->view('home',$data); 
    }
    
    public function add_user(){
       $this->call->library('Form_validation');
        $lname = $this->io->post('lastname');
        $fname = $this->io->post('firstname');
        $age = $this->io->post('age');
        $bind = array(
            "lastname" => $lname,
            "firstname" => $fname,
            "age" => $age,
        );
        $this->db->table('user')->insert($bind);
        redirect('home');
         if ($this->Form_validation->run() == false)
        {
            $this->call->view('home');
        } 
        else
        {
            $this->call->view('home');
        }
    }
    
public function delete_user($id){
    if (isset($id)){
        $this->db->table('user')->where("id", $id)->delete();
        redirect('home');
    }else{
        $_SESSION['delete'] = "failed to delete";
        redirect('home');
    }
}

public function edit_user($id = null){

    $this->call->model('user_model');
        $data['user'] = $this->user_model->getUsers();

        if(isset($id)){
            $data['edit'] = $this->user_model->searchUser($id);
        } else{
            $data['edit'] =null;
        }
       
        $this->call->view('home',$data); 
}	
public function SubmitEdit($id){
    if (isset($id)){
        $lname = $this->io->post('lastname');
        $fname = $this->io->post('firstname');
        $age = $this->io->post('age');
        $data = array (

            "last name" => $lname,
            "firstname" => $fname,
            "age" => $age,
        );
        $this->db->table('user')->where('id', $id)->update($data);
        redirect('home');
    }
 }
}

?>
