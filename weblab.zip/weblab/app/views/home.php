<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Simple Form</title>
  <!-- Add Bootstrap CSS link here -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
  <div class="container">
    <h2 class="mt-4">User Information</h2>
    <form action="/submit" method="post">
      <div class="form-group">
        <label for="lastname">Last Name:</label>
        <input type="text" class="form-control" name="lastname" value="<?= isset($edit_user['id']) ? $edit_user['lastname'] : '' ?>">
      </div>
      <div class="form-group">
        <label for="firstname">First Name:</label>
        <input type="text" class="form-control" name="firstname" value="<?= isset($edit_user['id']) ? $edit_user['firstname'] : '' ?>">
      </div>
      <div class="form-group">
        <label for="age">Age:</label>
        <input type="number" class="form-control" name="age" value="<?= isset($edit_user['id']) ? $edit_user['age'] : '' ?>">
      </div>
      <button type="submit" class="btn btn-primary"><?= (isset($edit_user['id'])) ? 'Update' : 'Submit' ?></button>
    </form>
  </div>

  <div class="container mt-4">
    <h2>User List</h2>
    <div class="table-container">
      <table class="table">
        <thead>
          <tr>
            <th>Last Name</th>
            <th>First Name</th>
            <th>Age</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($user as $a): ?>
            <tr>
              <td><?= $a['lastname']; ?></td>
              <td><?= $a['firstname']; ?></td>
              <td><?= $a['age']; ?></td>
              <td>
                <a href="/delete_user/<?= $a['id']; ?>" class="btn btn-danger">Delete</a>
                <a href="/edit_user/<?= $a['id']; ?>" class="btn btn-primary">Edit</a>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Add Bootstrap JS and jQuery script links here -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@1.16.0/dist/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
